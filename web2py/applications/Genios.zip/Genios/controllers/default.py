#Metodo principal
def index():
    message= "WHAAT?"
    return dict(message=message)
